<?php
$poin = 700; // test poin
$hadiahTambahan = $poin > 500 ? "YA" : "TIDAK";
echo "Skor saat ini: " . $poin . "<br>";
echo "Apakah pemain mendapat hadiah tambahan? $hadiahTambahan";


?>